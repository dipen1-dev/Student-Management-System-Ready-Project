package com.example.registrationLogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistrationLoginSpringbootSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
